package controller;

import business.ApplicationContext;
import business.book.Book;
import business.cart.ShoppingCart;
import viewmodel.CartViewModel;

import javax.servlet.ServletException;
import javax.servlet.annotation.HttpConstraint;
import javax.servlet.annotation.ServletSecurity;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@ServletSecurity(@HttpConstraint(transportGuarantee = ServletSecurity.TransportGuarantee.CONFIDENTIAL))
@WebServlet(name = "CartServlet", urlPatterns = {"/cart"})

public class CartServlet extends BookstoreServlet {

    protected void doPost(HttpServletRequest request,
                          HttpServletResponse response)
            throws ServletException, IOException {

        String action = request.getParameter("action");
        ShoppingCart cart = (ShoppingCart) request.getSession().getAttribute("cart");
        String bookIdText = request.getParameter("bookId");
        long bookId = Long.parseLong(bookIdText);
        Book book = ApplicationContext.INSTANCE.getBookDao().findByBookId(bookId);
        String currentCategory = request.getParameter("category");

        if ("add".equals(action)) {
            cart.addItem(book);
            // ajax
            boolean isAjaxRequest =
                    "XMLHttpRequest".equalsIgnoreCase(request.getHeader("X-Requested-With"));
            if (isAjaxRequest) {
                String jsonString = "{\"cartCount\": " + cart.getNumberOfItems() + "}";
                response.setContentType("application/json");
                response.getWriter().write(jsonString);
                response.flushBuffer();
            } else {
                response.sendRedirect(request.getContextPath() + "/category?category=" + currentCategory);
            }
            return;

        } else if ("update".equals(action)) {

            // get input from request
            String quantityText = request.getParameter("quantity");

            try {
                int quantity = Integer.parseInt(quantityText);
                cart.update(book, quantity);
            } catch ( Exception e ) {
                //no message sent
            }
            // using post-redirect-get pattern
        } else if ("empty".equals(action)){
            try {
                cart.clear();
            } catch ( Exception e ) {
                //no message sent
            }
            // using post-redirect-get pattern
        } else {
            // do nothing
        }
        response.sendRedirect(request.getContextPath() + "/cart");
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        request.setAttribute("p", new CartViewModel(request));
        forwardToJsp(request, response, "/cart");
    }
}
