package controller;

import business.ApplicationContext;
import business.book.Book;
import business.book.BookDao;
import business.category.Category;
import business.category.CategoryDao;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;

@WebServlet(name = "Test", urlPatterns = {"/test"})
public class TestServlet extends HttpServlet {

    protected void doPost(HttpServletRequest request,
                          HttpServletResponse response)
            throws ServletException, IOException {

    }

    protected void doGet(HttpServletRequest request,
                         HttpServletResponse response)
            throws ServletException, IOException {

        String selectedCategoryName = request.getParameter("category");
        if (selectedCategoryName == null) {
            selectedCategoryName = "science-fiction";
        }

        CategoryDao categoryDao = ApplicationContext.INSTANCE.getCategoryDao();
        BookDao bookDao = ApplicationContext.INSTANCE.getBookDao();

        //use the category name to get the category object (using findByName)
        Category category = categoryDao.findByName(selectedCategoryName);

        //get category ID from the category object (using get method)
        long categoryId = category.getCategoryId();

        //get selected-book-list using (findByCategoryId method) bookDao
        List<Book> selectedCategoryBookList = bookDao.findByCategoryId(categoryId);

        request.setAttribute("selectedCategoryName", selectedCategoryName);

        //set book-list attribute
        request.setAttribute("selectedCategoryBookList", selectedCategoryBookList);

        String userPath = "/test";
        String url = "/WEB-INF/jsp" + userPath + ".jsp";

        RequestDispatcher dispatcher = request.getRequestDispatcher(url);
        dispatcher.forward(request, response);
    }
}
