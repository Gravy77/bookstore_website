package viewmodel;

import business.customer.CustomerForm;

import javax.servlet.http.HttpServletRequest;
import java.util.Calendar;

public class CheckoutViewModel extends BaseViewModel {

    private CustomerForm customerForm;
    private Boolean hasTransactionError;
    private Boolean hasValidationError;

    public CheckoutViewModel(HttpServletRequest request) {
        super(request);

        CustomerForm sessionForm = (CustomerForm) session.getAttribute("customerForm");
        customerForm = (sessionForm == null) ? new CustomerForm() : sessionForm;

        hasValidationError = (Boolean) session.getAttribute("validationError");
        session.setAttribute("validationError", null);

        hasTransactionError = (Boolean) session.getAttribute("transactionError");
        request.getSession().setAttribute("transactionError", null);
    }

    public CustomerForm getCustomerForm() {
        return customerForm;
    }

    public boolean getHasValidationError() {
        return hasValidationError != null && hasValidationError;
    }

    public boolean getHasTransactionError() {
        return hasTransactionError != null && hasTransactionError;
    }

    public String getDefaultExpiryMonth() {
        Calendar calendar = Calendar.getInstance();
        if (customerForm.getCcExpDate() != null) {
            calendar.setTime(customerForm.getCcExpDate());
            String ccExpMonth = Integer.toString(calendar.get(Calendar.MONTH) + 1);
            return ccExpMonth;
        }
        return "1";
    }

    public String getDefaultExpiryYear() {
        Calendar calendar = Calendar.getInstance();
        if (customerForm.getCcExpDate() != null) {
            calendar.setTime(customerForm.getCcExpDate());
            String ccExpYear = Integer.toString(calendar.get(Calendar.YEAR));
            return ccExpYear;
        }
        return "2019";
    }
}
