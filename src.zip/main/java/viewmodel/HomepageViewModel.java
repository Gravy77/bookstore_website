package viewmodel;

import javax.servlet.http.HttpServletRequest;

public class HomepageViewModel extends BaseViewModel{

    public HomepageViewModel(HttpServletRequest request) {
        super(request);
    }
}
