package viewmodel;

import business.order.OrderDetails;

import javax.servlet.http.HttpServletRequest;
import java.util.Calendar;
import java.util.Date;

import static java.util.Calendar.MONTH;

public class ConfirmationViewModel extends BaseViewModel{

    private long orderId;
    private OrderDetails orderDetails;

    public ConfirmationViewModel(HttpServletRequest request) {
        super(request);
        this.orderDetails = (OrderDetails) session.getAttribute("orderDetails");
    }

    public long getOrderId() {
        return orderId;
    }

    public OrderDetails getOrderDetails() {
        return orderDetails;
    }

    public String getCcNumberForDisplay() {
        String ccNumberForDisplay = "";
        String ccNumber = orderDetails.getCustomer().getCcNumber();
        int ccLength = ccNumber.length();
        String lastFour = ccNumber.substring(ccLength - 4);
        for (int i = 0; i < ccLength - 4; i++) {
            ccNumberForDisplay += "*";
        }
        ccNumberForDisplay += lastFour;
        return ccNumberForDisplay;
    }

    public String getCcMonthForDisplay() {
        Date ccExpiry = orderDetails.getCustomer().getCcExpDate();
        Calendar c = Calendar.getInstance();
        c.setTime(ccExpiry);
        int month = c.get(MONTH);
        int displayMonth = month + 1;
        String displayMonthString = Integer.toString(displayMonth);
        if (displayMonthString.length() < 2) {
            displayMonthString = "0" + displayMonthString;
        }
        return displayMonthString;
    }

    public boolean orderNotAvailable() {
        if (orderDetails == null) {
            return true;
        }
        return false;
    }
}
