package viewmodel;

import business.book.Book;
import business.category.Category;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import java.util.List;

public class CategoryViewModel extends BaseViewModel {

    private Category selectedCategory;
    private List<Book> selectedCategoryBooks;
    private static final String TAG = CategoryViewModel.class.getSimpleName();

    public CategoryViewModel(HttpServletRequest request) {
        super(request);

        System.out.println("TAG = " + TAG);
        HttpSession session = request.getSession();

        String categoryName = request.getParameter("category");
        if (isValidName(categoryName)) {
            selectedCategory = categoryDao.findByName(categoryName);
            rememberSelectedCategory(session, selectedCategory);
        } else {
            if (recallSelectedCategory(session) != null) {
                selectedCategory = recallSelectedCategory(session);
            } else {
                selectedCategory = getDefaultCategory();
            }
        }
        selectedCategoryBooks = bookDao.findByCategoryId(selectedCategory.getCategoryId());
    }

    private boolean isValidName(String name) {
        if (name == null) {
            return false;
        }
        for (Category c : getCategories()) {
            if (name.equals(c.getName())) {
                return true;
            }
        }
        return false;
    }

    public Category getSelectedCategory() {
        return selectedCategory;
    }

    public List<Book> getSelectedCategoryBooks() {
        return selectedCategoryBooks;
    }

    private void rememberSelectedCategory(HttpSession session, Category selectedCategory) {
        session.setAttribute("selectedCategory", selectedCategory);
    }

    private Category recallSelectedCategory(HttpSession session) {
        return (Category) session.getAttribute("selectedCategory");
    }

    private Category getDefaultCategory() {
        // Default category is science-fiction which is id number 1001
        return categoryDao.findByCategoryId(1001);
    }
}
