package business.customer;

import java.util.Calendar;
import java.util.Date;

public class  CustomerForm {

    private static boolean DEBUG = false;

    private String name;
    private String address;
    private String phone;
    private String email;
    private String ccNumber;
    private Date ccExpDate;

    private boolean hasNameError;
    private boolean hasAddressError;
    private boolean hasPhoneError;
    private boolean hasEmailError;
    private boolean hasCcNumberError;
    private boolean hasCcExpDateError;

    public CustomerForm() {

        this(
                DEBUG ? "Tom Thumb" : "",
                DEBUG ? "123 Thumb Drive" : "",
                DEBUG ? "7035551212" : "",
                DEBUG ? "tom@thumb.com" : "",
                DEBUG ? "4444 3333 2222 1111" : "",
                DEBUG ? "6" : "1",
                DEBUG ? "2023" : "2019"
        );
    }

    public CustomerForm(String name, String address, String phone, String email, String ccNumber, String ccMonth, String ccYear) {
        this.name = name;
        this.address = address;
        this.phone = phone;
        this.email = email;
        this.ccNumber = ccNumber;

        ccExpDate = getCcExpDate(ccMonth, ccYear);
        validate();
    }

    // Get methods for fields

    public String getName() {
        return name;
    }

    public String getAddress() {
        return address;
    }

    public String getPhone() {
        return phone;
    }

    public String getEmail() {
        return email;
    }

    public String getCcNumber() {
        return ccNumber;
    }

    public Date getCcExpDate() {
        return ccExpDate;
    }

    // hasError methods for fields

    public boolean getHasNameError() {
        return hasNameError;
    }

    public boolean getHasAddressError() {
        return hasAddressError;
    }

    public boolean getHasPhoneError() {
        return hasPhoneError;
    }

    public boolean getHasEmailError() {
        return hasEmailError;
    }

    public boolean getHasCcNumberError() {
        return hasCcNumberError;
    }

    public boolean getHasCcExpDateError() {
        return hasCcExpDateError;
    }

    public boolean getHasFieldError() {
        return hasNameError || hasAddressError || hasPhoneError || hasEmailError || hasCcNumberError || hasCcExpDateError;
    }

    // error messages for fields

    public String getNameErrorMessage() {

        return "Valid name required (ex: Bilbo Baggins)";
    }

    public String getAddressErrorMessage() {

        return "Valid address required (ex: 123 Fake St. Seattle WA)";
    }

    public String getPhoneErrorMessage() {

        return "Valid US phone required (ex: 555-555-5555)"; // also should handle (555) 555-5555
    }

    public String getEmailErrorMessage() {

        return "Valid email address required (ex: myname@example.com)";
    }

    public String getCcNumberErrorMessage() {

        return "Valid Credit Card Number required (ex: 1111222233334444)";
    }

    public String getCcExpDateErrorMessage() {

        Calendar calendar = Calendar.getInstance();
        int year = calendar.get(Calendar.YEAR);
        year++;
        calendar.set(Calendar.YEAR, year);
        return "Credit Card Expiry must be after today's date (ex: " + (calendar.get(Calendar.MONTH) + 1) + "/" + calendar.get(Calendar.YEAR) + ")";
    }

    private void validate() {
        if (name.trim() == null || name.trim().equals("") || name.length() > 45) {
            hasNameError = true;
        }

        if (address.trim() == null || address.trim().equals("") || address.length() > 45) {
            hasAddressError = true;
        }

        boolean phoneIsInvalid = false;
        // strip all digits from phone string
        String phoneDigits = phone.replaceAll("\\D", "");

        if (!phoneDigits.matches("\\d+")) {
            phoneIsInvalid = true;
        }

        if (phoneDigits.length() != 10) {
            phoneIsInvalid = true;
        }

        if (phoneIsInvalid) {
            hasPhoneError = true;
        }

        if (!email.matches("^[\\w-_\\.+]*[\\w-_\\.]\\@([\\w]+\\.)+[\\w]+[\\w]$")) {
            hasEmailError = true;
        }

        ccNumber = ccNumber.replaceAll("\\D", "");
        if (!ccNumber.matches("\\d+") || !(ccNumber.length() >= 14 && ccNumber.length() <= 16)) {
            hasCcNumberError = true;
        }

        if (ccExpDate.compareTo(new Date()) < 0) {
            hasCcExpDateError = true;
        }
    }

    // Returns a Java date object with the specified month and year
    private Date getCcExpDate(String ccMonth, String ccYear) {
        // Assume monthString is an integer between 1 and 12
        int month = Integer.parseInt(ccMonth);
        // Assume yearString is a four-digit integer
        int year = Integer.parseInt(ccYear);
        // Note: Calendar.getInstance() returns a calendar object
        Calendar calendar = Calendar.getInstance();
        // Note: calendar.set(Calendar.MONTH, mm) sets the month
        calendar.set(Calendar.MONTH, month - 1);
        // Note: calendar.set(Calendar.YEAR, yyyy) sets the year
        calendar.set(Calendar.YEAR, year);
        // Note: Be careful of one-off errors
        return calendar.getTime();
    }
}
